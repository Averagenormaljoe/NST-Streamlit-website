def reset_warp_frames(config):
    config["warp_frames"] = []
    return config