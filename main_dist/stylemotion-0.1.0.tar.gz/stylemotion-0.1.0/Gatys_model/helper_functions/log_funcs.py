from shared_utils.helper import create_dir
def create_log_dir(content_name : str, style_name : str):
    log_folder : str = "logs/tensorboard"
    log_dir = f"{log_folder}/{content_name}_{style_name}"
    create_dir(log_dir)
    return log_dir