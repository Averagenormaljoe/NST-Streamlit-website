import keras
def get_layer_names_for_loss_net(name: str) -> list[str]:
    if name == "vgg19":
        layer_names : list[str] = ["block1_conv1", "block2_conv1", "block3_conv1", "block4_conv2", "block5_conv1"]
        return layer_names
    if name == "vgg19-min":
        layer_names : list[str] =  ["block1_conv1", "block2_conv1", "block3_conv1"]
        return layer_names
    if name == "vgg19-max":
        layer_names : list[str] = ["block1_conv1", "block2_conv1", "block3_conv1", "block4_conv2", "block5_conv1", "block5_conv2"]
        return layer_names 
    elif name == "vgg16":
        layer_names : list[str] = ["block1_conv1", "block2_conv1", "block3_conv1", "block4_conv2", "block5_conv1"]
        return layer_names
    elif name == "vgg13":
        layer_names : list[str] = ["block1_conv1", "block2_conv1", "block3_conv1", "block4_conv2", "block5_conv1"]
        return layer_names
    
    elif name == "altvgg19":
        layer_names : list[str] =  ["block1_conv2", "block2_conv2", "block3_conv3", "block4_conv3"]
        return layer_names
    elif name == "mobilenet":
        layer_names : list[str] = ["block_1_expand_relu", "block_3_expand_relu", "block_6_expand_relu", "block_13_expand_relu"]
        return layer_names
    elif name == "efficientnet":
        layer_names : list[str] = ["block2a_expand_activation", "block3a_expand_activation", "block4a_expand_activation", "block6a_expand_activation"]
        return layer_names
    elif name == "resnet50":
        layer_names : list[str] = ["conv1_relu", "conv2_block3_out", "conv3_block4_out", "conv4_block6_out"]
        return layer_names
    elif name == "inceptionv3":
        layer_names : list[str] = ["conv2d_1", "conv2d_2", "conv2d_3", "mixed7"]
        return layer_names
    elif name == "xception":
        layer_names : list[str] = ["block1_conv1", "block2_sepconv2_bn", "block3_sepconv2_bn", "block4_sepconv2_bn"]
        return layer_names
    else:
        raise ValueError(f"Unknown model name: {name}")

def get_model_for_loss_net(name : str,image_size: tuple[int, int] = (224, 224))-> keras.Model:
    if name == "vgg19":
        vgg19 = keras.applications.VGG19(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return vgg19
    elif name == "altvgg19":
        altvgg19 = keras.applications.VGG19(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return altvgg19
    elif name == "vgg16":
        vgg16 = keras.applications.VGG16(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return vgg16
    elif name == "vgg13":
        vgg13 = keras.applications.VGG13(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return vgg13    
    elif name == "vgg11": 
        vgg11 = keras.applications.VGG11(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return vgg11
    elif name == "vgg10":
        vgg10 = keras.applications.VGG10(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return vgg10
    elif name == "vgg8":
        vgg8 = keras.applications.VGG8(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return vgg8
    elif name == "vgg7":
        vgg7 = keras.applications.VGG7(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return vgg7
    elif name == "vgg6":
        vgg6 = keras.applications.VGG6(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return vgg6
    elif name == "mobilenet":
        mobilenet = keras.applications.MobileNetV2(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return mobilenet
    elif name == "efficientnet":
        efficientnet = keras.applications.EfficientNetB0(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return efficientnet
    elif name == "resnet50":
        resnet50 = keras.applications.ResNet50(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return resnet50
    elif name == "inceptionv3":
        inceptionv3 = keras.applications.InceptionV3(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return inceptionv3
    elif name == "xception":
        xception = keras.applications.Xception(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return xception
    elif name == "densenet121":
        densenet121 = keras.applications.DenseNet121(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return densenet121
    elif name == "squeezenet":
        squeezenet = keras.applications.SqueezeNet(
        include_top=False, weights="imagenet", input_shape=(*image_size, 3)
        )
        return squeezenet
    else:
        raise ValueError(f"Unknown model name: {name}")