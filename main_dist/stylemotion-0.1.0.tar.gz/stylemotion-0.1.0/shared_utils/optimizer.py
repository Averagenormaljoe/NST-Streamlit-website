import tensorflow_probability as tfp
import keras
def get_optimizer(model_name: str, learning_rate: float):
    name : str = model_name.lower()
    if name == 'adam':
        return keras.optimizers.Adam(learning_rate=learning_rate)
    elif name == 'sgd':
        return SGD(keras.optimizers.schedules.ExponentialDecay(initial_learning_rate=learning_rate, decay_steps=100, decay_rate=0.96))
    elif name == 'rmsprop':
        return keras.optimizers.RMSprop(learning_rate=learning_rate)
    elif name == 'adagrad':
        return keras.optimizers.Adagrad(learning_rate=learning_rate)
    elif name == 'adamax':
        return keras.optimizers.Adamax(learning_rate=learning_rate)
    elif name == 'nadam':
        return keras.optimizers.Nadam(learning_rate=learning_rate)
    elif name == 'radam':
        return keras.optimizers.RAdam(learning_rate=learning_rate)
    elif name == 'lbfgs':
        return tfp.optimizer.lbfgs_minimize
    elif name == 'ftrl':
        return keras.optimizers.Ftrl(learning_rate=learning_rate)
    elif name == "lion":
        optimizer = keras.optimizers.Lion(
        learning_rate=1e-4, 
        beta_1=0.9,
        beta_2=0.99,
        weight_decay=1e-2   
        )
        return optimizer
    elif name == "adamw":
        return keras.optimizers.AdamW(learning_rate=learning_rate, weight_decay=1e-4) 
      
    else:
        print(f"Unknown optimizer {name}. Using Adam by default.")
        return keras.optimizers.Adam(learning_rate=learning_rate)
   