
def get_content_layer_names(name: str = "vgg19") -> list[str]:
    if name == "vgg19":
        return ["block5_conv2"]
    elif name == "vgg16":
        return ["block5_conv2"]
    elif name == "altvgg19":
        return ["block4_conv3"]
    elif name == "mobilenet":
        return ["block_13_expand_relu"]
    elif name == "efficientnet":
        return ["block6a_expand_activation"]
    elif name == "resnet50":
        return ["conv4_block6_out"]
    elif name == "inceptionv3":
        return ["mixed7"]
    elif name == "xception":
        return ["block4_sepconv2_bn"]
    elif name == "densenet121":
        return ["pool4_relu"]
    else:
        raise ValueError(f"Unknown model name: {name}")
def get_style_layer_names(name: str = "vgg19") -> list[str]:
    if name == "vgg19":
        return ["block1_conv1", "block2_conv1", "block3_conv1", "block4_conv2"]
    elif name == "vgg16":
        return ["block1_conv1", "block2_conv1", "block3_conv1", "block4_conv2"]
    elif name == "altvgg19":
        return ["block1_conv2", "block2_conv2", "block3_conv3"]
    elif name == "mobilenet":
        return ["block_1_expand_relu", "block_3_expand_relu", "block_6_expand_relu"]
    elif name == "efficientnet":
        return ["block2a_expand_activation", "block3a_expand_activation", "block4a_expand_activation"]
    elif name == "resnet50":
        return ["conv1_relu", "conv2_block3_out", "conv3_block4_out"]
    elif name == "inceptionv3":
        return ["conv2d_1", "conv2d_2", "conv2d_3"]
    elif name == "xception":
        return ["block1_conv1", "block2_sepconv2_bn", "block3_sepconv2_bn"]
    elif name == "densenet121":
        return ["conv1/relu", "pool2_relu", "pool3_relu", "pool4_relu"]
    else:
        raise ValueError(f"Unknown model name: {name}")

def get_style_weights(name: str = "vgg19"):
    if name == "vgg19":
        style_weights = {'block1_conv1': 1.,
                 'block2_conv1': 0.8,
                 'block3_conv1': 0.5,
                 'block4_conv1': 0.3,
                 'block5_conv1': 0.1}
        return style_weights
    elif name == "altvgg19":
        style_weights = {'block1_conv2': 1.,
                 'block2_conv2': 0.6,
                 'block3_conv3': 0.5}
        return style_weights
    elif name == "mobilenet":
        style_weights = {'block_1_expand_relu': 1.,
                 'block_3_expand_relu': 0.6,
                 'block_6_expand_relu': 0.4}
        return style_weights
    else:
        raise ValueError(f"Unknown model name: {name}")
    
def get_content_weights(name: str = "vgg19"):
    if name == "vgg19":
        return {'block5_conv2': 1.0}
    elif name == "altvgg19":
        return {'block4_conv3': 1.0}
    elif name == "mobilenet":
        return {'block_13_expand_relu': 1.0}
    elif name == "efficientnet":
        return {'block6a_expand_activation': 1.0}
    elif name == "resnet50":
        return {'conv4_block6_out': 1.0}
    elif name == "inceptionv3":
        return {'mixed7': 1.0}
    elif name == "xception":
        return {'block4_sepconv2_bn': 1.0}
    else:
        raise ValueError(f"Unknown model name: ({name})")