import tensorflow as tf


def apply_sample_to_model(model, sample = [1, 224, 224, 3]):
    
    sample_content = tf.random.normal(sample)  
    sample_style = tf.random.normal(sample)   
    _ = model(content_image=sample_content, style_image=sample_style)