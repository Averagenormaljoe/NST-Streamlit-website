import os
def retrieve_style_image(images_path: str):
    style_images = os.listdir(images_path)
    extensions = ('.jpg', '.jpeg', '.png')
    style_images = [os.path.join(images_path, path) for path in style_images if path.endswith(extensions)]
    return style_images

# Get the image file paths for the style images.
def get_style_images(on_kaggle : bool = True, dataset : str = "artwork"):
    if dataset == "artwork":
        if on_kaggle:
            style_images = retrieve_style_image("/kaggle/input/best-artworks-of-all-time/resized/resized")
            return style_images
        else:
            style_images = retrieve_style_image("/content/artwork/resized")
            return style_images
    else:
        style_images = retrieve_style_image("/kaggle/input/wikiart")
            

def split_style_images(on_kaggle : bool, dataset : str = "artwork"):
    style_images = get_style_images(on_kaggle, dataset)
    total_style_images = len(style_images)
    train_split = int(0.8 * total_style_images)
    train_style = style_images[: train_split]
    val_split = int(0.9 * total_style_images)
    val_style = style_images[train_split : val_split]
    test_split = int(0.9 * total_style_images)
    test_style = style_images[test_split :]
    return train_style, val_style, test_style