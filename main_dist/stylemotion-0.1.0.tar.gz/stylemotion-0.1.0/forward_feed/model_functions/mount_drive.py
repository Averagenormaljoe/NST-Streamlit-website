# Downloading or scraping some images from internet (nature,person,portrait,dogs,cat,moutains,paintings,city,traffic,horses,monkey,indoor scenes ..etc )
def mount_drive(on_colab=False):
    if on_colab:
        from google.colab import drive
        drive.mount("/gdrive")